package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BuiltInLogo
import com.example.data.model.QrCornerStyle
import com.example.data.model.QrDesignOptions
import com.example.data.model.QrDotStyle
import com.example.data.model.QrErrorCorrection
import com.example.data.model.QrFrameStyle
import com.example.ui.MainViewModel
import com.example.ui.navigation.Screen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.IndigoPrimary

@Composable
fun DesignerScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val designOptions by viewModel.designOptions.collectAsState()
    val generatedBitmap by viewModel.generatedBitmap.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val activeContent by viewModel.activeContent.collectAsState()
    val selectedType by viewModel.selectedType.collectAsState()

    var hexInput by remember { mutableStateOf("") }

    // Custom Logo picker
    val customLogoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.updateDesignOptions(
                designOptions.copy(
                    customLogoPath = uri.toString(),
                    builtInLogo = BuiltInLogo.NONE,
                    // Automatically raise error correction to High for logo scannability
                    errorCorrection = QrErrorCorrection.HIGH
                )
            )
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("designer_screen"),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Top Bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp, start = 12.dp, end = 20.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { onNavigate(Screen.Create.route) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Generator")
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Custom QR Designer",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(
                    onClick = {
                        viewModel.resetDesignOptions()
                        Toast.makeText(context, "Reset to defaults", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Icon(Icons.Default.RestartAlt, contentDescription = "Reset Defaults")
                }
            }
        }

        // Live QR Preview Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(230.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(modifier = Modifier.size(36.dp))
                        } else if (generatedBitmap != null) {
                            Image(
                                bitmap = generatedBitmap!!.asImageBitmap(),
                                contentDescription = "Live Styled QR Preview",
                                modifier = Modifier.size(215.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Live preview updates instantly with your styles",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Color Palettes & Custom HEX
        item {
            SectionHeader(title = "1. Color Themes & Palettes")
            Spacer(modifier = Modifier.height(10.dp))

            val palettes = listOf(
                "Classic Black" to (android.graphics.Color.BLACK to android.graphics.Color.WHITE),
                "Modern Indigo" to (android.graphics.Color.parseColor("#4F46E5") to android.graphics.Color.WHITE),
                "Sunset Amber" to (android.graphics.Color.parseColor("#E11D48") to android.graphics.Color.parseColor("#FFF1F2")),
                "Emerald Green" to (android.graphics.Color.parseColor("#059669") to android.graphics.Color.WHITE),
                "Neon Cyan" to (android.graphics.Color.parseColor("#0891B2") to android.graphics.Color.parseColor("#ECFEFF")),
                "Dark Luxury" to (android.graphics.Color.parseColor("#E2E8F0") to android.graphics.Color.parseColor("#0F172A")),
                "Pastel Violet" to (android.graphics.Color.parseColor("#7C3AED") to android.graphics.Color.parseColor("#F5F3FF"))
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                palettes.forEach { (name, pair) ->
                    val isSelected = designOptions.foregroundColor == pair.first && designOptions.backgroundColor == pair.second
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                viewModel.updateDesignOptions(
                                    designOptions.copy(
                                        foregroundColor = pair.first,
                                        backgroundColor = pair.second
                                    )
                                )
                            },
                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(Color(pair.first))
                                    .border(1.dp, Color(pair.second), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Custom HEX input
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = hexInput,
                    onValueChange = { hexInput = it },
                    label = { Text("Custom HEX (e.g. #1E40AF)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                Button(
                    onClick = {
                        try {
                            val parsedColor = android.graphics.Color.parseColor(
                                if (!hexInput.startsWith("#")) "#$hexInput" else hexInput
                            )
                            viewModel.updateDesignOptions(designOptions.copy(foregroundColor = parsedColor))
                            Toast.makeText(context, "Foreground color applied!", Toast.LENGTH_SHORT).show()
                        } catch (_: Exception) {
                            Toast.makeText(context, "Invalid HEX color format", Toast.LENGTH_SHORT).show()
                        }
                    },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Apply")
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Corner Styles
        item {
            SectionHeader(title = "2. Corner Eye Styles")
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QrCornerStyle.entries.forEach { corner ->
                    FilterChip(
                        selected = designOptions.cornerStyle == corner,
                        onClick = { viewModel.updateDesignOptions(designOptions.copy(cornerStyle = corner)) },
                        label = { Text(corner.displayName) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Dot Styles
        item {
            SectionHeader(title = "3. Dot / Module Styles")
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QrDotStyle.entries.forEach { dot ->
                    FilterChip(
                        selected = designOptions.dotStyle == dot,
                        onClick = { viewModel.updateDesignOptions(designOptions.copy(dotStyle = dot)) },
                        label = { Text(dot.displayName) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Frames
        item {
            SectionHeader(title = "4. Frames & Badges")
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QrFrameStyle.entries.forEach { frame ->
                    FilterChip(
                        selected = designOptions.frameStyle == frame,
                        onClick = { viewModel.updateDesignOptions(designOptions.copy(frameStyle = frame)) },
                        label = { Text(frame.displayName) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Center Logo
        item {
            SectionHeader(title = "5. Center Logo")
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BuiltInLogo.entries.forEach { logo ->
                    val isSelected = designOptions.builtInLogo == logo && designOptions.customLogoPath == null
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            viewModel.updateDesignOptions(
                                designOptions.copy(
                                    builtInLogo = logo,
                                    customLogoPath = null,
                                    errorCorrection = if (logo != BuiltInLogo.NONE) QrErrorCorrection.HIGH else designOptions.errorCorrection
                                )
                            )
                        },
                        label = { Text(logo.displayName) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Upload custom logo
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { customLogoPicker.launch("image/*") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Upload Custom Logo from Gallery")
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Sizes (Resolution)
        item {
            SectionHeader(title = "6. Resolution & Output Size")
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(512 to "512x512", 1024 to "1024x1024", 2048 to "2048 Ultra HD").forEach { (sz, label) ->
                    val isSelected = designOptions.size == sz
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            viewModel.updateDesignOptions(designOptions.copy(size = sz))
                        },
                        label = { Text(label) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Error Correction
        item {
            SectionHeader(title = "7. Error Correction Level")
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QrErrorCorrection.entries.forEach { level ->
                    FilterChip(
                        selected = designOptions.errorCorrection == level,
                        onClick = { viewModel.updateDesignOptions(designOptions.copy(errorCorrection = level)) },
                        label = { Text(level.displayName) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(28.dp))
        }

        // Final Action Buttons
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        viewModel.saveQrToGallery(context, isPng = true) { success, msg ->
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("designer_save_png_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Download Styled QR as PNG")
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            viewModel.saveQrToGallery(context, isPng = false) { success, msg ->
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Download JPG")
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.shareQrCode(context) { _, msg ->
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share")
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(horizontal = 20.dp)
    )
}
