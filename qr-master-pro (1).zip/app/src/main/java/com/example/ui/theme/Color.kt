package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Utility / Minimal Palette
val BluePrimary = Color(0xFF2563EB) // Blue-600
val BluePrimaryDark = Color(0xFF3B82F6) // Blue-500
val BlueLight = Color(0xFF60A5FA) // Blue-400
val BluePrimaryContainer = Color(0xFFEFF6FF) // Blue-50
val BluePrimaryContainerDark = Color(0xFF1E3A8A) // Blue-900

val SkyAccent = Color(0xFF0284C7) // Sky-600
val SkyAccentDark = Color(0xFF38BDF8) // Sky-400

val IndigoTertiary = Color(0xFF4F46E5) // Indigo-600
val IndigoTertiaryDark = Color(0xFF818CF8) // Indigo-400

// Compatibility aliases
val IndigoPrimary = BluePrimary
val IndigoPrimaryDark = BluePrimaryDark
val CyanAccent = SkyAccent
val CyanAccentDark = SkyAccentDark
val VioletTertiary = IndigoTertiary
val VioletTertiaryDark = IndigoTertiaryDark

// Light Scheme (Clean Utility / Minimal)
val BackgroundLight = Color(0xFFF7F9FC) // Crisp minimal slate-ice background
val SurfaceLight = Color(0xFFFFFFFF) // Pure white card surfaces
val SurfaceVariantLight = Color(0xFFF1F5F9) // Slate-100 soft utility surface
val OutlineLight = Color(0xFFE2E8F0) // Slate-200 clean border
val OutlineVariantLight = Color(0xFFF1F5F9) // Slate-100
val TextPrimaryLight = Color(0xFF0F172A) // Slate-900
val TextSecondaryLight = Color(0xFF64748B) // Slate-500
val TextMutedLight = Color(0xFF94A3B8) // Slate-400 uppercase tracking

// Dark Scheme (Minimal Slate Utility)
val BackgroundDark = Color(0xFF0F172A) // Slate-900
val SurfaceDark = Color(0xFF1E293B) // Slate-800
val SurfaceVariantDark = Color(0xFF334155) // Slate-700
val OutlineDark = Color(0xFF334155)
val OutlineVariantDark = Color(0xFF1E293B)
val TextPrimaryDark = Color(0xFFF8FAFC) // Slate-50
val TextSecondaryDark = Color(0xFF94A3B8) // Slate-400

// Premium Amber Badge (from HTML design)
val AmberPremiumBg = Color(0xFFFEF3C7) // Amber-100
val AmberPremiumBorder = Color(0xFFFDE68A) // Amber-200
val AmberPremiumText = Color(0xFF92400E) // Amber-800

// Quick Action Pastel Tints (from HTML design)
val TintIndigoBg = Color(0xFFEEF2FF)
val TintIndigoFg = Color(0xFF4F46E5)
val TintEmeraldBg = Color(0xFFECFDF5)
val TintEmeraldFg = Color(0xFF059669)
val TintRoseBg = Color(0xFFFFF1F2)
val TintRoseFg = Color(0xFFE11D48)
val TintSkyBg = Color(0xFFF0F9FF)
val TintSkyFg = Color(0xFF0284C7)
val TintAmberBg = Color(0xFFFFFBEB)
val TintAmberFg = Color(0xFFD97706)

val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)


