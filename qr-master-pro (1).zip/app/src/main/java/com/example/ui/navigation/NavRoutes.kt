package com.example.ui.navigation

sealed class Screen(val route: String, val title: String) {
    data object Home : Screen("home", "Home")
    data object Scan : Screen("scan", "Scan")
    data object Create : Screen("create", "Create")
    data object History : Screen("history", "History")
    data object Settings : Screen("settings", "Settings")
    data object Designer : Screen("designer", "Custom Designer")
    data object Favorites : Screen("favorites", "Favorites")
    data object Onboarding : Screen("onboarding", "Welcome")
}
