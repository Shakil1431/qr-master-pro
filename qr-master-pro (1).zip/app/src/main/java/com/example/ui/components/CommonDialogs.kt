package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Rule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ErrorRed

@Composable
fun ClearHistoryDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(Icons.Default.DeleteForever, contentDescription = null, tint = ErrorRed)
        },
        title = {
            Text(text = "Clear All History?", fontWeight = FontWeight.Bold)
        },
        text = {
            Text("This action will permanently erase all scanned and generated QR code records. Favorites will also be cleared. Are you sure?")
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
            ) {
                Text("Clear All")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun PrivacyPolicyDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.Policy, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        title = { Text("Privacy Policy", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "QR Master Pro is designed with privacy-first principles:\n\n" +
                            "• Offline Processing: QR generation and standard scanning happen 100% locally on your device without sending content to any external cloud servers.\n\n" +
                            "• Camera Usage: The camera is utilized strictly during active scanning to decode barcodes in real-time. No video feeds or photos are stored or uploaded without your explicit command.\n\n" +
                            "• Storage & History: All your generated and scanned QR codes remain safely on your device's local Room database and can be deleted at any time.\n\n" +
                            "• Untrusted Input: Scanned links are never opened automatically. The app verifies domains and requires your direct authorization before initiating any browser navigation.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun TermsDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.Rule, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        title = { Text("Terms & Conditions", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "By using QR Master Pro, you agree to the following terms:\n\n" +
                            "• User Responsibility: You are solely responsible for content encoded into QR codes and verifying the authenticity of scanned links prior to opening.\n\n" +
                            "• Free & Complete Features: All QR code generation, scanning, high-resolution export, custom designs, and saved history features are completely free for all users.\n\n" +
                            "• Offline Reliability: QR Master Pro provides extensive offline utility. External web links naturally require active internet connectivity.\n\n" +
                            "• Updates: We continuously improve security and performance across Android releases.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
