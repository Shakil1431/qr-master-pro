package com.example.ui

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppThemeMode
import com.example.data.local.QrDatabase
import com.example.data.local.QrRepository
import com.example.data.local.UserPreferences
import com.example.data.model.QrData
import com.example.data.model.QrDesignOptions
import com.example.data.model.QrHistoryItem
import com.example.data.model.QrType
import com.example.service.AdsterraService
import com.example.service.QrGeneratorService
import com.example.service.QrScannerService
import com.example.service.SecurityAssessment
import com.example.service.SecurityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: QrRepository
    val userPreferences = UserPreferences(application)
    val adsterraService = AdsterraService()

    init {
        val db = QrDatabase.getInstance(application)
        repository = QrRepository(db.qrDao())
    }

    // --- Preferences ---
    val themeMode: StateFlow<AppThemeMode> = userPreferences.themeMode
    val language: StateFlow<String> = userPreferences.language
    val isOnboardingCompleted: StateFlow<Boolean> = userPreferences.isOnboardingCompleted

    fun setThemeMode(mode: AppThemeMode) = userPreferences.setThemeMode(mode)
    fun setLanguage(lang: String) = userPreferences.setLanguage(lang)
    fun setOnboardingCompleted(completed: Boolean) = userPreferences.setOnboardingCompleted(completed)

    // --- History & Favorites ---
    val allHistory: StateFlow<List<QrHistoryItem>> = repository.allHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scannedHistory: StateFlow<List<QrHistoryItem>> = repository.scannedHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val generatedHistory: StateFlow<List<QrHistoryItem>> = repository.generatedHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<List<QrHistoryItem>> = repository.favorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentItems: StateFlow<List<QrHistoryItem>> = repository.recentItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun toggleFavorite(item: QrHistoryItem, context: Context) {
        viewModelScope.launch {
            repository.toggleFavorite(item)
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch {
            repository.deleteById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }

    fun saveHistoryItem(title: String, content: String, type: QrType, isScanned: Boolean) {
        viewModelScope.launch {
            repository.insert(
                QrHistoryItem(
                    title = title.ifBlank { type.displayName },
                    content = content,
                    qrType = type.name,
                    isScanned = isScanned
                )
            )
        }
    }

    // --- Scanner State ---
    private val _scanResult = MutableStateFlow<String?>(null)
    val scanResult: StateFlow<String?> = _scanResult.asStateFlow()

    private val _parsedScanData = MutableStateFlow<QrData?>(null)
    val parsedScanData: StateFlow<QrData?> = _parsedScanData.asStateFlow()

    private val _securityAssessment = MutableStateFlow<SecurityAssessment?>(null)
    val securityAssessment: StateFlow<SecurityAssessment?> = _securityAssessment.asStateFlow()

    private val _isScanning = MutableStateFlow(true)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _isTorchEnabled = MutableStateFlow(false)
    val isTorchEnabled: StateFlow<Boolean> = _isTorchEnabled.asStateFlow()

    fun toggleTorch() {
        _isTorchEnabled.value = !_isTorchEnabled.value
    }

    fun onQrScanned(rawText: String, saveToDb: Boolean = true) {
        if (rawText.isBlank()) return
        _isScanning.value = false
        _scanResult.value = rawText

        val parsed = QrData.parseScannedText(rawText)
        _parsedScanData.value = parsed

        val assessment = SecurityService.assessContent(rawText)
        _securityAssessment.value = assessment

        if (saveToDb) {
            saveHistoryItem(
                title = parsed.displayTitle(),
                content = rawText,
                type = parsed.type,
                isScanned = true
            )
        }
    }

    fun resetScanner() {
        _scanResult.value = null
        _parsedScanData.value = null
        _securityAssessment.value = null
        _isScanning.value = true
    }

    fun scanImageFromGallery(context: Context, uri: Uri) {
        viewModelScope.launch {
            val result = QrScannerService.decodeUri(context, uri)
            result.onSuccess { text ->
                onQrScanned(text, saveToDb = true)
            }.onFailure { err ->
                Toast.makeText(
                    context,
                    "No valid QR code found in selected image: ${err.localizedMessage}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // --- Generator & Designer State ---
    private val _activeContent = MutableStateFlow("https://google.com")
    val activeContent: StateFlow<String> = _activeContent.asStateFlow()

    private val _selectedType = MutableStateFlow(QrType.URL)
    val selectedType: StateFlow<QrType> = _selectedType.asStateFlow()

    private val _designOptions = MutableStateFlow(QrDesignOptions.defaultOptions())
    val designOptions: StateFlow<QrDesignOptions> = _designOptions.asStateFlow()

    private val _generatedBitmap = MutableStateFlow<Bitmap?>(null)
    val generatedBitmap: StateFlow<Bitmap?> = _generatedBitmap.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    fun setQrContent(content: String, type: QrType) {
        _activeContent.value = content
        _selectedType.value = type
        regenerateQrBitmap()
    }

    fun updateDesignOptions(options: QrDesignOptions) {
        _designOptions.value = options
        regenerateQrBitmap()
    }

    fun resetDesignOptions() {
        _designOptions.value = QrDesignOptions.defaultOptions()
        regenerateQrBitmap()
    }

    fun regenerateQrBitmap() {
        viewModelScope.launch {
            _isGenerating.value = true
            try {
                val bmp = QrGeneratorService.generateQrBitmap(
                    content = _activeContent.value,
                    options = _designOptions.value,
                    context = getApplication()
                )
                _generatedBitmap.value = bmp
            } catch (_: Exception) {
            } finally {
                _isGenerating.value = false
            }
        }
    }

    fun saveQrToGallery(context: Context, isPng: Boolean, onComplete: (Boolean, String) -> Unit) {
        val bmp = _generatedBitmap.value
        if (bmp == null) {
            onComplete(false, "No QR Code generated yet")
            return
        }

        viewModelScope.launch {
            val result = QrGeneratorService.saveBitmapToGallery(
                context = context,
                bitmap = bmp,
                qrType = _selectedType.value.displayName,
                isPng = isPng
            )
            result.onSuccess {
                // Record action for ethical ad frequency control
                adsterraService.recordAction(context) {}
                onComplete(true, "Saved to Pictures/QRMaster!")
            }.onFailure { e ->
                onComplete(false, "Save failed: ${e.localizedMessage}")
            }
        }
    }

    fun shareQrCode(context: Context, onComplete: (Boolean, String) -> Unit) {
        val bmp = _generatedBitmap.value
        if (bmp == null) {
            onComplete(false, "No QR Code to share")
            return
        }

        viewModelScope.launch {
            val result = QrGeneratorService.getShareableUri(
                context = context,
                bitmap = bmp,
                qrType = _selectedType.value.displayName
            )
            result.onSuccess { uri ->
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_TEXT, _activeContent.value)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(sendIntent, "Share QR Code via").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
                onComplete(true, "Opening share sheet...")
            }.onFailure { e ->
                onComplete(false, "Share failed: ${e.localizedMessage}")
            }
        }
    }

    fun copyToClipboard(context: Context, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("QR Content", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Copied to clipboard!", Toast.LENGTH_SHORT).show()
    }

    fun openExternalUrl(context: Context, url: String) {
        try {
            val formatted = if (!url.startsWith("http://", ignoreCase = true) && !url.startsWith("https://", ignoreCase = true)) {
                "https://$url"
            } else {
                url
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(formatted)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open link: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }
}
