package com.example.ui.screens

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QrData
import com.example.data.model.QrType
import com.example.ui.MainViewModel
import com.example.ui.components.AdsterraBannerCard
import com.example.ui.navigation.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val selectedType by viewModel.selectedType.collectAsState()
    val generatedBitmap by viewModel.generatedBitmap.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()

    // Form inputs state
    var textInput by remember { mutableStateOf("") }
    var urlInput by remember { mutableStateOf("https://") }

    // Wi-Fi inputs
    var wifiSsid by remember { mutableStateOf("") }
    var wifiPassword by remember { mutableStateOf("") }
    var wifiEncryption by remember { mutableStateOf("WPA") }
    var wifiIsHidden by remember { mutableStateOf(false) }
    var wifiPasswordVisible by remember { mutableStateOf(false) }
    var wifiExpanded by remember { mutableStateOf(false) }

    // Phone & SMS
    var phoneNumber by remember { mutableStateOf("") }
    var smsMessage by remember { mutableStateOf("") }

    // Email
    var emailTo by remember { mutableStateOf("") }
    var emailSubject by remember { mutableStateOf("") }
    var emailBody by remember { mutableStateOf("") }

    // WhatsApp
    var waPhone by remember { mutableStateOf("") }
    var waMessage by remember { mutableStateOf("") }

    // Contact / vCard
    var contactFirstName by remember { mutableStateOf("") }
    var contactLastName by remember { mutableStateOf("") }
    var contactPhone by remember { mutableStateOf("") }
    var contactEmail by remember { mutableStateOf("") }
    var contactCompany by remember { mutableStateOf("") }
    var contactJobTitle by remember { mutableStateOf("") }

    // Location
    var locLatitude by remember { mutableStateOf("") }
    var locLongitude by remember { mutableStateOf("") }
    var locLabel by remember { mutableStateOf("") }

    var isSavedToHistory by remember { mutableStateOf(false) }

    fun buildCurrentPayload(): String {
        return when (selectedType) {
            QrType.TEXT -> textInput.ifBlank { "Hello from QR Master Pro" }
            QrType.URL -> {
                val u = urlInput.trim()
                if (u.isBlank() || u == "https://") "https://google.com" else u
            }
            QrType.WIFI -> {
                QrData.Wifi(
                    ssid = wifiSsid.ifBlank { "Home_WiFi" },
                    password = wifiPassword,
                    security = wifiEncryption,
                    hidden = wifiIsHidden
                ).formatToContent()
            }
            QrType.PHONE -> {
                QrData.Phone(number = phoneNumber.ifBlank { "+1234567890" }).formatToContent()
            }
            QrType.EMAIL -> {
                QrData.Email(
                    email = emailTo.ifBlank { "contact@example.com" },
                    subject = emailSubject,
                    body = emailBody
                ).formatToContent()
            }
            QrType.SMS -> {
                QrData.Sms(
                    number = phoneNumber.ifBlank { "+1234567890" },
                    message = smsMessage
                ).formatToContent()
            }
            QrType.WHATSAPP -> {
                QrData.WhatsApp(
                    phone = waPhone.ifBlank { "1234567890" },
                    message = waMessage
                ).formatToContent()
            }
            QrType.CONTACT -> {
                QrData.Contact(
                    firstName = contactFirstName.ifBlank { "John" },
                    lastName = contactLastName.ifBlank { "Doe" },
                    phone = contactPhone,
                    email = contactEmail,
                    company = contactCompany,
                    title = contactJobTitle
                ).formatToContent()
            }
            QrType.LOCATION -> {
                val lat = locLatitude.toDoubleOrNull() ?: 37.7749
                val lon = locLongitude.toDoubleOrNull() ?: -122.4194
                QrData.Location(lat, lon, locLabel).formatToContent()
            }
        }
    }

    // Auto-refresh QR bitmap when payload changes
    LaunchedEffect(
        selectedType, textInput, urlInput, wifiSsid, wifiPassword, wifiEncryption,
        wifiIsHidden, phoneNumber, smsMessage, emailTo, emailSubject, emailBody,
        waPhone, waMessage, contactFirstName, contactLastName, contactPhone,
        contactEmail, contactCompany, contactJobTitle, locLatitude, locLongitude, locLabel
    ) {
        val payload = buildCurrentPayload()
        viewModel.setQrContent(payload, selectedType)
        isSavedToHistory = false
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("create_screen"),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Top Title
        item {
            Column(modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 12.dp)) {
                Text(
                    text = "QR Generator",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Select format and enter content below",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Type Selector Tabs
        item {
            ScrollableTabRow(
                selectedTabIndex = QrType.entries.indexOf(selectedType),
                edgePadding = 20.dp,
                divider = {}
            ) {
                QrType.entries.forEach { type ->
                    Tab(
                        selected = selectedType == type,
                        onClick = { viewModel.setQrContent(buildCurrentPayload(), type) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(type.icon, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(type.displayName)
                            }
                        },
                        modifier = Modifier.testTag("tab_${type.name.lowercase()}")
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Input Forms per Type
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    when (selectedType) {
                        QrType.TEXT -> {
                            OutlinedTextField(
                                value = textInput,
                                onValueChange = { textInput = it },
                                label = { Text("Plain Text") },
                                placeholder = { Text("Enter any note, code, or description...") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_text"),
                                minLines = 3,
                                maxLines = 6
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${textInput.length} characters",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        QrType.URL -> {
                            OutlinedTextField(
                                value = urlInput,
                                onValueChange = { urlInput = it },
                                label = { Text("Website URL") },
                                placeholder = { Text("https://yourwebsite.com") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_url"),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                            )
                        }
                        QrType.WIFI -> {
                            OutlinedTextField(
                                value = wifiSsid,
                                onValueChange = { wifiSsid = it },
                                label = { Text("Network Name (SSID)") },
                                modifier = Modifier.fillMaxWidth().testTag("input_wifi_ssid"),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = wifiPassword,
                                onValueChange = { wifiPassword = it },
                                label = { Text("Password") },
                                modifier = Modifier.fillMaxWidth().testTag("input_wifi_password"),
                                singleLine = true,
                                visualTransformation = if (wifiPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            ExposedDropdownMenuBox(
                                expanded = wifiExpanded,
                                onExpandedChange = { wifiExpanded = !wifiExpanded }
                            ) {
                                OutlinedTextField(
                                    value = wifiEncryption,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Security Type") },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = wifiExpanded) },
                                    modifier = Modifier
                                        .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                        .fillMaxWidth()
                                )
                                ExposedDropdownMenu(
                                    expanded = wifiExpanded,
                                    onDismissRequest = { wifiExpanded = false }
                                ) {
                                    listOf("WPA", "WEP", "nopass").forEach { sec ->
                                        DropdownMenuItem(
                                            text = { Text(if (sec == "nopass") "None (Open)" else sec) },
                                            onClick = {
                                                wifiEncryption = sec
                                                wifiExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                Checkbox(
                                    checked = wifiIsHidden,
                                    onCheckedChange = { wifiIsHidden = it }
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Hidden Network", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        QrType.PHONE -> {
                            OutlinedTextField(
                                value = phoneNumber,
                                onValueChange = { phoneNumber = it },
                                label = { Text("Phone Number") },
                                placeholder = { Text("+1 (555) 000-0000") },
                                modifier = Modifier.fillMaxWidth().testTag("input_phone"),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                            )
                        }
                        QrType.EMAIL -> {
                            OutlinedTextField(
                                value = emailTo,
                                onValueChange = { emailTo = it },
                                label = { Text("Recipient Email") },
                                placeholder = { Text("name@example.com") },
                                modifier = Modifier.fillMaxWidth().testTag("input_email"),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = emailSubject,
                                onValueChange = { emailSubject = it },
                                label = { Text("Subject (Optional)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = emailBody,
                                onValueChange = { emailBody = it },
                                label = { Text("Message Body (Optional)") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2
                            )
                        }
                        QrType.SMS -> {
                            OutlinedTextField(
                                value = phoneNumber,
                                onValueChange = { phoneNumber = it },
                                label = { Text("Recipient Phone Number") },
                                modifier = Modifier.fillMaxWidth().testTag("input_sms_phone"),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = smsMessage,
                                onValueChange = { smsMessage = it },
                                label = { Text("SMS Message") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2
                            )
                        }
                        QrType.WHATSAPP -> {
                            OutlinedTextField(
                                value = waPhone,
                                onValueChange = { waPhone = it },
                                label = { Text("Phone Number (with Country Code)") },
                                placeholder = { Text("15551234567") },
                                modifier = Modifier.fillMaxWidth().testTag("input_whatsapp_phone"),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = waMessage,
                                onValueChange = { waMessage = it },
                                label = { Text("Pre-filled Message (Optional)") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2
                            )
                        }
                        QrType.CONTACT -> {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = contactFirstName,
                                    onValueChange = { contactFirstName = it },
                                    label = { Text("First Name") },
                                    modifier = Modifier.weight(1f).testTag("input_contact_fname"),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = contactLastName,
                                    onValueChange = { contactLastName = it },
                                    label = { Text("Last Name") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = contactPhone,
                                onValueChange = { contactPhone = it },
                                label = { Text("Phone Number") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = contactEmail,
                                onValueChange = { contactEmail = it },
                                label = { Text("Email Address") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = contactCompany,
                                    onValueChange = { contactCompany = it },
                                    label = { Text("Company") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = contactJobTitle,
                                    onValueChange = { contactJobTitle = it },
                                    label = { Text("Job Title") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                        }
                        QrType.LOCATION -> {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = locLatitude,
                                    onValueChange = { locLatitude = it },
                                    label = { Text("Latitude") },
                                    placeholder = { Text("37.7749") },
                                    modifier = Modifier.weight(1f).testTag("input_lat"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                                )
                                OutlinedTextField(
                                    value = locLongitude,
                                    onValueChange = { locLongitude = it },
                                    label = { Text("Longitude") },
                                    placeholder = { Text("-122.4194") },
                                    modifier = Modifier.weight(1f).testTag("input_lon"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = locLabel,
                                onValueChange = { locLabel = it },
                                label = { Text("Location Name / Address (Optional)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                    }
                }
            }
        }

        // Live QR Code Preview Card
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Live Preview",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .size(240.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(modifier = Modifier.size(40.dp))
                        } else if (generatedBitmap != null) {
                            Image(
                                bitmap = generatedBitmap!!.asImageBitmap(),
                                contentDescription = "Generated QR Preview",
                                modifier = Modifier.size(220.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Shortcut to Open Custom Designer
                    OutlinedButton(
                        onClick = { onNavigate(Screen.Designer.route) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("open_designer_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Palette, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Customize in Designer (Colors, Logo, Frames)")
                    }
                }
            }
        }

        // Action Buttons Row (Download PNG, JPG, Copy, Share, Save)
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Download row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.saveQrToGallery(context, isPng = true) { success, msg ->
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f).height(48.dp).testTag("download_png_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save PNG")
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.saveQrToGallery(context, isPng = false) { success, msg ->
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f).height(48.dp).testTag("download_jpg_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save JPG")
                    }
                }

                // Copy & Share & Save to History
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            viewModel.copyToClipboard(context, buildCurrentPayload())
                        },
                        modifier = Modifier.weight(1f).height(48.dp).testTag("copy_content_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy")
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.shareQrCode(context) { _, msg ->
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f).height(48.dp).testTag("share_qr_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share")
                    }

                    OutlinedButton(
                        onClick = {
                            val payload = buildCurrentPayload()
                            viewModel.saveHistoryItem(
                                title = "${selectedType.displayName} QR",
                                content = payload,
                                type = selectedType,
                                isScanned = false
                            )
                            isSavedToHistory = true
                            Toast.makeText(context, "Saved to History!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f).height(48.dp).testTag("save_history_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = if (isSavedToHistory) {
                            ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                        } else {
                            ButtonDefaults.outlinedButtonColors()
                        }
                    ) {
                        Icon(
                            if (isSavedToHistory) Icons.Default.Check else Icons.Default.BookmarkBorder,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isSavedToHistory) "Saved" else "Save")
                    }
                }
            }
        }

        // Adsterra Banner area
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                AdsterraBannerCard(adsterraService = viewModel.adsterraService)
            }
        }
    }
}
