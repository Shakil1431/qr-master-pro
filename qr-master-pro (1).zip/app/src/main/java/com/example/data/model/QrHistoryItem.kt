package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "qr_history")
data class QrHistoryItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val qrType: String,
    val isScanned: Boolean,
    val isFavorite: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun getFormattedDateTime(): String {
        val sdf = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun getQrTypeEnum(): QrType {
        return QrType.fromString(qrType)
    }
}
