package com.example.data.model

import android.graphics.Color

enum class QrCornerStyle(val displayName: String) {
    SQUARE("Square"),
    ROUNDED("Rounded"),
    EXTRA_ROUNDED("Pill"),
    DOT("Dot / Ring")
}

enum class QrDotStyle(val displayName: String) {
    SQUARE("Classic Block"),
    CIRCLE("Round Dots"),
    ROUNDED("Soft Squares")
}

enum class QrFrameStyle(val displayName: String) {
    NONE("No Frame"),
    BORDER("Clean Border"),
    SCAN_ME("Scan Me Tag"),
    BADGE("Modern Badge")
}

enum class QrErrorCorrection(val displayName: String, val levelCode: String) {
    LOW("Low (7%)", "L"),
    MEDIUM("Medium (15%)", "M"),
    QUARTILE("High (25%)", "Q"),
    HIGH("Ultra (30% - Best with logo)", "H")
}

enum class BuiltInLogo(val id: String, val displayName: String) {
    NONE("none", "None"),
    QR("qr", "QR Symbol"),
    WEB("web", "Globe"),
    WIFI("wifi", "Wi-Fi"),
    CONTACT("contact", "User"),
    WHATSAPP("whatsapp", "Chat"),
    STAR("star", "Star"),
    HEART("heart", "Heart"),
    LOCK("lock", "Shield")
}

data class QrDesignOptions(
    val foregroundColor: Int = Color.BLACK,
    val backgroundColor: Int = Color.WHITE,
    val size: Int = 1024,
    val cornerStyle: QrCornerStyle = QrCornerStyle.SQUARE,
    val dotStyle: QrDotStyle = QrDotStyle.SQUARE,
    val frameStyle: QrFrameStyle = QrFrameStyle.NONE,
    val errorCorrection: QrErrorCorrection = QrErrorCorrection.HIGH,
    val builtInLogo: BuiltInLogo = BuiltInLogo.NONE,
    val customLogoPath: String? = null
) {
    companion object {
        fun defaultOptions(): QrDesignOptions = QrDesignOptions()
    }
}
