package com.example.data.model

import android.net.Uri
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class QrData {
    abstract val type: QrType
    abstract fun formatToContent(): String
    abstract fun displayTitle(): String

    data class Text(val text: String) : QrData() {
        override val type = QrType.TEXT
        override fun formatToContent(): String = text
        override fun displayTitle(): String = if (text.length > 30) text.take(30) + "..." else text
    }

    data class Url(val url: String) : QrData() {
        override val type = QrType.URL
        override fun formatToContent(): String {
            return if (!url.startsWith("http://", ignoreCase = true) && !url.startsWith("https://", ignoreCase = true)) {
                "https://$url"
            } else {
                url
            }
        }
        override fun displayTitle(): String = url
    }

    data class Wifi(
        val ssid: String,
        val password: String = "",
        val security: String = "WPA", // WPA, WEP, nopass
        val hidden: Boolean = false
    ) : QrData() {
        override val type = QrType.WIFI
        override fun formatToContent(): String {
            val sec = if (security.equals("nopass", ignoreCase = true)) "nopass" else security
            return "WIFI:S:$ssid;T:$sec;P:$password;H:${if (hidden) "true" else "false"};;"
        }
        override fun displayTitle(): String = "Wi-Fi: $ssid ($security)"
    }

    data class Phone(val number: String) : QrData() {
        override val type = QrType.PHONE
        override fun formatToContent(): String = "tel:$number"
        override fun displayTitle(): String = "Call $number"
    }

    data class Email(
        val email: String,
        val subject: String = "",
        val body: String = ""
    ) : QrData() {
        override val type = QrType.EMAIL
        override fun formatToContent(): String {
            val encodedSubject = URLEncoder.encode(subject, StandardCharsets.UTF_8.name())
            val encodedBody = URLEncoder.encode(body, StandardCharsets.UTF_8.name())
            return "mailto:$email?subject=$encodedSubject&body=$encodedBody"
        }
        override fun displayTitle(): String = "Email to $email"
    }

    data class Sms(
        val number: String,
        val message: String = ""
    ) : QrData() {
        override val type = QrType.SMS
        override fun formatToContent(): String {
            return if (message.isNotBlank()) "smsto:$number:$message" else "smsto:$number"
        }
        override fun displayTitle(): String = "SMS to $number"
    }

    data class WhatsApp(
        val phone: String,
        val message: String = ""
    ) : QrData() {
        override val type = QrType.WHATSAPP
        override fun formatToContent(): String {
            val cleanPhone = phone.replace("+", "").replace(" ", "").replace("-", "")
            val encodedMsg = URLEncoder.encode(message, StandardCharsets.UTF_8.name())
            return if (message.isNotBlank()) {
                "https://wa.me/$cleanPhone?text=$encodedMsg"
            } else {
                "https://wa.me/$cleanPhone"
            }
        }
        override fun displayTitle(): String = "WhatsApp: $phone"
    }

    data class Contact(
        val firstName: String,
        val lastName: String = "",
        val phone: String = "",
        val email: String = "",
        val company: String = "",
        val title: String = ""
    ) : QrData() {
        override val type = QrType.CONTACT
        override fun formatToContent(): String {
            val sb = StringBuilder()
            sb.append("BEGIN:VCARD\n")
            sb.append("VERSION:3.0\n")
            sb.append("N:$lastName;$firstName;;;\n")
            sb.append("FN:$firstName $lastName\n")
            if (phone.isNotBlank()) sb.append("TEL;TYPE=CELL:$phone\n")
            if (email.isNotBlank()) sb.append("EMAIL:$email\n")
            if (company.isNotBlank()) sb.append("ORG:$company\n")
            if (title.isNotBlank()) sb.append("TITLE:$title\n")
            sb.append("END:VCARD")
            return sb.toString()
        }
        override fun displayTitle(): String = "$firstName $lastName".trim().ifBlank { "Contact Card" }
    }

    data class Location(
        val latitude: Double,
        val longitude: Double,
        val queryName: String = ""
    ) : QrData() {
        override val type = QrType.LOCATION
        override fun formatToContent(): String {
            return if (queryName.isNotBlank()) {
                val encoded = URLEncoder.encode(queryName, StandardCharsets.UTF_8.name())
                "geo:$latitude,$longitude?q=$encoded"
            } else {
                "geo:$latitude,$longitude?q=$latitude,$longitude"
            }
        }
        override fun displayTitle(): String = queryName.ifBlank { "Lat: $latitude, Lng: $longitude" }
    }

    companion object {
        fun parseScannedText(raw: String): QrData {
            val trimmed = raw.trim()

            // Check WiFi
            if (trimmed.startsWith("WIFI:", ignoreCase = true)) {
                var ssid = ""
                var pass = ""
                var sec = "WPA"
                var hidden = false
                val parts = trimmed.removePrefix("WIFI:").removePrefix("wifi:").split(";")
                for (part in parts) {
                    if (part.startsWith("S:")) ssid = part.substring(2)
                    if (part.startsWith("P:")) pass = part.substring(2)
                    if (part.startsWith("T:")) sec = part.substring(2)
                    if (part.startsWith("H:")) hidden = part.substring(2).toBoolean()
                }
                return Wifi(ssid = ssid, password = pass, security = sec, hidden = hidden)
            }

            // Check vCard
            if (trimmed.startsWith("BEGIN:VCARD", ignoreCase = true)) {
                var fn = ""
                var tel = ""
                var email = ""
                var org = ""
                trimmed.lines().forEach { line ->
                    val cleanLine = line.trim()
                    if (cleanLine.startsWith("FN:", ignoreCase = true)) fn = cleanLine.substring(3).trim()
                    else if (cleanLine.startsWith("TEL", ignoreCase = true)) tel = cleanLine.substringAfter(":").trim()
                    else if (cleanLine.startsWith("EMAIL", ignoreCase = true)) email = cleanLine.substringAfter(":").trim()
                    else if (cleanLine.startsWith("ORG:", ignoreCase = true)) org = cleanLine.substring(4).trim()
                }
                return Contact(firstName = fn, phone = tel, email = email, company = org)
            }

            // Check Phone
            if (trimmed.startsWith("tel:", ignoreCase = true)) {
                return Phone(trimmed.substring(4).trim())
            }

            // Check Email
            if (trimmed.startsWith("mailto:", ignoreCase = true)) {
                val emailPart = trimmed.substring(7).substringBefore("?")
                val subjectPart = if (trimmed.contains("subject=")) trimmed.substringAfter("subject=").substringBefore("&") else ""
                val bodyPart = if (trimmed.contains("body=")) trimmed.substringAfter("body=").substringBefore("&") else ""
                return Email(email = emailPart, subject = Uri.decode(subjectPart), body = Uri.decode(bodyPart))
            }

            // Check SMS
            if (trimmed.startsWith("smsto:", ignoreCase = true) || trimmed.startsWith("sms:", ignoreCase = true)) {
                val clean = trimmed.removePrefix("smsto:").removePrefix("sms:")
                val number = clean.substringBefore(":")
                val msg = clean.substringAfter(":", "")
                return Sms(number = number, message = msg)
            }

            // Check WhatsApp
            if (trimmed.contains("wa.me/") || trimmed.contains("api.whatsapp.com/send")) {
                val phone = trimmed.substringAfter("wa.me/").substringBefore("?").substringBefore("/")
                val msg = if (trimmed.contains("text=")) trimmed.substringAfter("text=").substringBefore("&") else ""
                return WhatsApp(phone = phone, message = Uri.decode(msg))
            }

            // Check Geo Location
            if (trimmed.startsWith("geo:", ignoreCase = true)) {
                val coords = trimmed.substring(4).substringBefore("?").split(",")
                val lat = coords.getOrNull(0)?.toDoubleOrNull() ?: 0.0
                val lng = coords.getOrNull(1)?.toDoubleOrNull() ?: 0.0
                val q = if (trimmed.contains("q=")) Uri.decode(trimmed.substringAfter("q=").substringBefore("&")) else ""
                return Location(latitude = lat, longitude = lng, queryName = q)
            }

            // Check Web URL
            if (trimmed.startsWith("http://", ignoreCase = true) ||
                trimmed.startsWith("https://", ignoreCase = true) ||
                (trimmed.contains(".") && !trimmed.contains(" ") && (trimmed.startsWith("www.", ignoreCase = true) || trimmed.matches(Regex("^[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}(/.*)?$"))))
            ) {
                val validUrl = if (!trimmed.startsWith("http://", ignoreCase = true) && !trimmed.startsWith("https://", ignoreCase = true)) {
                    "https://$trimmed"
                } else {
                    trimmed
                }
                return Url(validUrl)
            }

            // Default Text
            return Text(trimmed)
        }
    }
}
