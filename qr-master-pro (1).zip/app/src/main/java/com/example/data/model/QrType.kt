package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ContactPage
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.ui.graphics.vector.ImageVector

enum class QrType(
    val displayName: String,
    val description: String,
    val icon: ImageVector
) {
    TEXT("Plain Text", "Encode any text note or snippet", Icons.Default.Notes),
    URL("Website URL", "Direct link to any web page", Icons.Default.Language),
    WIFI("Wi-Fi", "Connect automatically to Wi-Fi", Icons.Default.Wifi),
    PHONE("Phone Number", "Direct one-tap phone dialer", Icons.Default.Call),
    EMAIL("Email", "Pre-composed email with subject", Icons.Default.AlternateEmail),
    SMS("SMS", "Pre-filled text message to phone", Icons.Default.Message),
    WHATSAPP("WhatsApp", "Chat directly on WhatsApp", Icons.Default.Chat),
    CONTACT("Contact / vCard", "Full digital business card", Icons.Default.ContactPage),
    LOCATION("Location", "Map coordinates or address", Icons.Default.LocationOn);

    companion object {
        fun fromString(name: String): QrType {
            return entries.find { it.name.equals(name, ignoreCase = true) } ?: TEXT
        }
    }
}
