package com.example.data.local

import com.example.data.model.QrHistoryItem
import kotlinx.coroutines.flow.Flow

class QrRepository(private val qrDao: QrDao) {

    val allHistory: Flow<List<QrHistoryItem>> = qrDao.getAllHistory()
    val scannedHistory: Flow<List<QrHistoryItem>> = qrDao.getScannedHistory()
    val generatedHistory: Flow<List<QrHistoryItem>> = qrDao.getGeneratedHistory()
    val favorites: Flow<List<QrHistoryItem>> = qrDao.getFavorites()
    val recentItems: Flow<List<QrHistoryItem>> = qrDao.getRecentHistory(5)
    val favoriteCount: Flow<Int> = qrDao.getFavoriteCount()

    suspend fun insert(item: QrHistoryItem): Long = qrDao.insert(item)

    suspend fun update(item: QrHistoryItem) = qrDao.update(item)

    suspend fun toggleFavorite(item: QrHistoryItem) {
        qrDao.updateFavorite(item.id, !item.isFavorite)
    }

    suspend fun deleteById(id: Long) = qrDao.deleteById(id)

    suspend fun clearAll() = qrDao.clearAll()
}
