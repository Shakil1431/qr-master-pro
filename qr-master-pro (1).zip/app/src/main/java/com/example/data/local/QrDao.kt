package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.QrHistoryItem
import kotlinx.coroutines.flow.Flow

@Dao
interface QrDao {

    @Query("SELECT * FROM qr_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<QrHistoryItem>>

    @Query("SELECT * FROM qr_history WHERE isScanned = 1 ORDER BY timestamp DESC")
    fun getScannedHistory(): Flow<List<QrHistoryItem>>

    @Query("SELECT * FROM qr_history WHERE isScanned = 0 ORDER BY timestamp DESC")
    fun getGeneratedHistory(): Flow<List<QrHistoryItem>>

    @Query("SELECT * FROM qr_history WHERE isFavorite = 1 ORDER BY timestamp DESC")
    fun getFavorites(): Flow<List<QrHistoryItem>>

    @Query("SELECT * FROM qr_history ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentHistory(limit: Int = 5): Flow<List<QrHistoryItem>>

    @Query("SELECT COUNT(*) FROM qr_history WHERE isFavorite = 1")
    fun getFavoriteCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: QrHistoryItem): Long

    @Update
    suspend fun update(item: QrHistoryItem)

    @Query("UPDATE qr_history SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavorite(id: Long, isFavorite: Boolean)

    @Query("DELETE FROM qr_history WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM qr_history")
    suspend fun clearAll()
}
