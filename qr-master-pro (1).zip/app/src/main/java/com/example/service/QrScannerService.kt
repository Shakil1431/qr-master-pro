package com.example.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.net.Uri
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer

object QrScannerService {

    private val reader = MultiFormatReader().apply {
        val hints = mapOf(
            DecodeHintType.POSSIBLE_FORMATS to listOf(
                BarcodeFormat.QR_CODE,
                BarcodeFormat.DATA_MATRIX,
                BarcodeFormat.AZTEC
            ),
            DecodeHintType.TRY_HARDER to true,
            DecodeHintType.CHARACTER_SET to "UTF-8"
        )
        setHints(hints)
    }

    /**
     * Decodes QR code from a Bitmap (e.g. chosen from gallery)
     */
    suspend fun decodeBitmap(bitmap: Bitmap): Result<String> = withContext(Dispatchers.Default) {
        try {
            val width = bitmap.width
            val height = bitmap.height
            val pixels = IntArray(width * height)
            bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

            val source = RGBLuminanceSource(width, height, pixels)
            val binaryBitmap = BinaryBitmap(HybridBinarizer(source))
            val result = reader.decodeWithState(binaryBitmap)
            Result.success(result.text)
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            reader.reset()
        }
    }

    /**
     * Loads a Bitmap from content URI and decodes it
     */
    suspend fun decodeUri(context: Context, uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val bitmap = BitmapFactory.decodeStream(stream)
                    ?: return@withContext Result.failure(Exception("Could not decode image from gallery"))
                return@withContext decodeBitmap(bitmap)
            } ?: Result.failure(Exception("Unable to open image file"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * CameraX ImageAnalysis.Analyzer for fast real-time frame scanning
     */
    class CameraAnalyzer(
        private val onQrDetected: (String) -> Unit
    ) : ImageAnalysis.Analyzer {

        private var isScanningEnabled = true

        fun setScanningEnabled(enabled: Boolean) {
            isScanningEnabled = enabled
        }

        @OptIn(ExperimentalGetImage::class)
        override fun analyze(imageProxy: ImageProxy) {
            if (!isScanningEnabled) {
                imageProxy.close()
                return
            }

            val mediaImage = imageProxy.image
            if (mediaImage != null && mediaImage.format == ImageFormat.YUV_420_888) {
                try {
                    val buffer = mediaImage.planes[0].buffer
                    val data = toByteArray(buffer)
                    val width = imageProxy.width
                    val height = imageProxy.height

                    val source = PlanarYUVLuminanceSource(
                        data,
                        width,
                        height,
                        0,
                        0,
                        width,
                        height,
                        false
                    )

                    val binaryBitmap = BinaryBitmap(HybridBinarizer(source))
                    val result = reader.decodeWithState(binaryBitmap)

                    if (!result.text.isNullOrBlank()) {
                        isScanningEnabled = false
                        onQrDetected(result.text)
                    }
                } catch (_: Exception) {
                    // Normal during camera panning when no valid QR in frame
                } finally {
                    reader.reset()
                    imageProxy.close()
                }
            } else {
                imageProxy.close()
            }
        }

        private fun toByteArray(buffer: ByteBuffer): ByteArray {
            buffer.rewind()
            val data = ByteArray(buffer.remaining())
            buffer.get(data)
            return data
        }
    }
}
