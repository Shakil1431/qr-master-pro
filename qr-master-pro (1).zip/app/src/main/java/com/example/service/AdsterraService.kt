package com.example.service

import android.content.Context
import android.content.Intent
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AdsterraService {

    private var actionCount = 0
    private var lastInterstitialTime = 0L

    private val _showInterstitialDialog = MutableStateFlow(false)
    val showInterstitialDialog: StateFlow<Boolean> = _showInterstitialDialog.asStateFlow()

    fun recordAction(context: Context, onProceed: () -> Unit) {
        actionCount++
        val now = System.currentTimeMillis()
        val elapsedSeconds = (now - lastInterstitialTime) / 1000

        // Strict frequency control
        if (actionCount >= AdsterraConfig.MIN_ACTIONS_BETWEEN_INTERSTITIALS &&
            elapsedSeconds >= AdsterraConfig.MIN_SECONDS_BETWEEN_INTERSTITIALS
        ) {
            actionCount = 0
            lastInterstitialTime = now
            _showInterstitialDialog.value = true
        }

        onProceed()
    }

    fun dismissInterstitial() {
        _showInterstitialDialog.value = false
    }

    fun openDirectLink(context: Context) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AdsterraConfig.ADSTERRA_DIRECT_LINK)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    fun buildBannerHtml(): String {
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
                <style>
                    body {
                        margin: 0;
                        padding: 0;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        background: transparent;
                        overflow: hidden;
                    }
                </style>
            </head>
            <body>
                ${AdsterraConfig.ADSTERRA_BANNER_SCRIPT}
            </body>
            </html>
        """.trimIndent()
    }
}
