package com.example.service

/**
 * Centralized Adsterra Configuration
 * Modify ad tags, scripts, and links here in one single place.
 */
object AdsterraConfig {

    // Adsterra Banner (320x50 iframe script)
    const val ADSTERRA_BANNER_SCRIPT = """
<script type="text/javascript">
  atOptions = {
    'key' : 'ce5e7cff656029ce2507b48701c47f37',
    'format' : 'iframe',
    'height' : 50,
    'width' : 320,
    'params' : {}
  };
</script>
<script type="text/javascript" src="https://www.highrevenueformat.com/ce5e7cff656029ce2507b48701c47f37/invoke.js"></script>
"""

    // Adsterra Social Bar Script
    const val ADSTERRA_SOCIAL_BAR_SCRIPT = """
<script src="https://pl30174651.profitableratecpmnetwork.com/8f/50/c5/8f50c5faeaa6b62324731457c2b543a8.js"></script>
"""

    // Adsterra Direct Link (used for interstitial/monetized click-outs)
    const val ADSTERRA_DIRECT_LINK = "https://www.profitableratecpmnetwork.com/csqxdda4f?key=8503e385c3198f768a73404ae1afc60a"

    // Adsterra Native Ad Container & Script
    const val ADSTERRA_NATIVE_CONTAINER = """
<script async="async" data-cfasync="false" src="https://pl30174650.profitableratecpmnetwork.com/12e4e51c8c192289d3177350a47f8f3a/invoke.js"></script>
<div id="container-12e4e51c8c192289d3177350a47f8f3a"></div>
"""

    // Frequency capping parameters
    const val MIN_ACTIONS_BETWEEN_INTERSTITIALS = 4
    const val MIN_SECONDS_BETWEEN_INTERSTITIALS = 75L // minimum 75s between full screen ads
}
