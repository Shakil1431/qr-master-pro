package com.example.service

import android.net.Uri
import java.util.Locale

enum class RiskLevel {
    SAFE, CAUTION, HIGH_RISK
}

data class SecurityAssessment(
    val riskLevel: RiskLevel,
    val domain: String,
    val warnings: List<String>,
    val fullSanitizedContent: String,
    val isExecutableOrDownload: Boolean = false,
    val isUntrustedScript: Boolean = false
)

object SecurityService {

    private val SUSPICIOUS_TLDS = setOf(
        "zip", "top", "xyz", "click", "rest", "cam", "fit", "tk", "ml", "ga", "cf", "gq", "work", "loan"
    )

    private val SUSPICIOUS_EXTENSIONS = setOf(
        "apk", "exe", "dmg", "bat", "cmd", "msi", "scr", "vbs", "jar", "sh", "bin", "ps1"
    )

    fun assessContent(rawInput: String): SecurityAssessment {
        val trimmed = rawInput.trim()
        val warnings = mutableListOf<String>()
        var risk = RiskLevel.SAFE
        var domain = ""
        var isExecutable = false
        var isScript = false

        // Check for javascript: or dangerous URI schemes
        if (trimmed.startsWith("javascript:", ignoreCase = true) ||
            trimmed.startsWith("data:text/html", ignoreCase = true) ||
            trimmed.startsWith("vbscript:", ignoreCase = true)
        ) {
            warnings.add("Untrusted script scheme detected. Arbitrary script execution is blocked.")
            return SecurityAssessment(
                riskLevel = RiskLevel.HIGH_RISK,
                domain = "Script / Untrusted Scheme",
                warnings = warnings,
                fullSanitizedContent = trimmed,
                isUntrustedScript = true
            )
        }

        // Check if URL
        val isUrl = trimmed.startsWith("http://", ignoreCase = true) ||
                trimmed.startsWith("https://", ignoreCase = true) ||
                (trimmed.contains(".") && !trimmed.contains(" ") && trimmed.startsWith("www.", ignoreCase = true))

        if (isUrl) {
            val urlString = if (!trimmed.startsWith("http://", ignoreCase = true) && !trimmed.startsWith("https://", ignoreCase = true)) {
                "https://$trimmed"
            } else {
                trimmed
            }

            try {
                val uri = Uri.parse(urlString)
                domain = uri.host ?: ""

                // Check HTTP vs HTTPS
                if (uri.scheme?.equals("http", ignoreCase = true) == true) {
                    warnings.add("Unencrypted connection (HTTP). Data transmitted over this link is not encrypted.")
                    if (risk == RiskLevel.SAFE) risk = RiskLevel.CAUTION
                }

                // Check IP address host
                if (domain.matches(Regex("^\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}$"))) {
                    warnings.add("Host is a raw numerical IP address ($domain) rather than a verified domain name.")
                    risk = RiskLevel.HIGH_RISK
                }

                // Check TLD
                val tld = domain.substringAfterLast(".", "").lowercase(Locale.ROOT)
                if (SUSPICIOUS_TLDS.contains(tld)) {
                    warnings.add("The domain ends in .$tld, a top-level domain frequently associated with spam or phishing.")
                    if (risk != RiskLevel.HIGH_RISK) risk = RiskLevel.CAUTION
                }

                // Check executable file download
                val path = uri.path ?: ""
                val fileExt = path.substringAfterLast(".", "").lowercase(Locale.ROOT)
                if (SUSPICIOUS_EXTENSIONS.contains(fileExt)) {
                    warnings.add("This link points directly to a downloadable executable or package file (.$fileExt).")
                    risk = RiskLevel.HIGH_RISK
                    isExecutable = true
                }

                // Check deceptive domain spoofing
                val parts = domain.split(".")
                if (parts.size > 3) {
                    val subdomains = parts.dropLast(2)
                    if (subdomains.any { it.contains("paypal") || it.contains("google") || it.contains("apple") || it.contains("bank") || it.contains("account") }) {
                        warnings.add("Potential spoofed domain detected. Brand names appear in subdomains rather than primary domain.")
                        risk = RiskLevel.HIGH_RISK
                    }
                }

                // Check non-standard port
                if (uri.port != -1 && uri.port != 80 && uri.port != 443) {
                    warnings.add("Destination uses non-standard network port: ${uri.port}.")
                    if (risk == RiskLevel.SAFE) risk = RiskLevel.CAUTION
                }

            } catch (e: Exception) {
                warnings.add("Could not verify URL structure: ${e.localizedMessage}")
                risk = RiskLevel.CAUTION
            }
        } else {
            domain = "Text / Data"
        }

        return SecurityAssessment(
            riskLevel = risk,
            domain = domain.ifBlank { "Unknown Host" },
            warnings = warnings,
            fullSanitizedContent = trimmed,
            isExecutableOrDownload = isExecutable,
            isUntrustedScript = isScript
        )
    }
}
