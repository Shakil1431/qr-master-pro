package com.example.service

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.data.model.BuiltInLogo
import com.example.data.model.QrCornerStyle
import com.example.data.model.QrDesignOptions
import com.example.data.model.QrDotStyle
import com.example.data.model.QrErrorCorrection
import com.example.data.model.QrFrameStyle
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object QrGeneratorService {

    suspend fun generateQrBitmap(
        content: String,
        options: QrDesignOptions = QrDesignOptions.defaultOptions(),
        context: Context? = null
    ): Bitmap = withContext(Dispatchers.Default) {
        if (content.isBlank()) {
            return@withContext Bitmap.createBitmap(options.size, options.size, Bitmap.Config.ARGB_8888).apply {
                eraseColor(options.backgroundColor)
            }
        }

        val zxingErrorLevel = when (options.errorCorrection) {
            QrErrorCorrection.LOW -> ErrorCorrectionLevel.L
            QrErrorCorrection.MEDIUM -> ErrorCorrectionLevel.M
            QrErrorCorrection.QUARTILE -> ErrorCorrectionLevel.Q
            QrErrorCorrection.HIGH -> ErrorCorrectionLevel.H
        }

        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to zxingErrorLevel,
            EncodeHintType.MARGIN to 1,
            EncodeHintType.CHARACTER_SET to "UTF-8"
        )

        val writer = MultiFormatWriter()
        val bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, 0, 0, hints)
        val matrixWidth = bitMatrix.width
        val matrixHeight = bitMatrix.height

        val qrSize = options.size
        val cellSize = qrSize.toFloat() / matrixWidth

        // Base QR bitmap
        val qrBitmap = Bitmap.createBitmap(qrSize, qrSize, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(qrBitmap)
        canvas.drawColor(options.backgroundColor)

        val fgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = options.foregroundColor
            style = Paint.Style.FILL
        }

        val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = options.foregroundColor
            style = Paint.Style.FILL
        }

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = options.backgroundColor
            style = Paint.Style.FILL
        }

        fun isFinderPattern(x: Int, y: Int): Boolean {
            val isTopLeft = x < 7 && y < 7
            val isTopRight = x >= matrixWidth - 7 && y < 7
            val isBottomLeft = x < 7 && y >= matrixHeight - 7
            return isTopLeft || isTopRight || isBottomLeft
        }

        // 1. Draw Data Modules (excluding finder pattern 7x7 blocks)
        for (x in 0 until matrixWidth) {
            for (y in 0 until matrixHeight) {
                if (bitMatrix.get(x, y)) {
                    if (isFinderPattern(x, y)) continue

                    val left = x * cellSize
                    val top = y * cellSize
                    val right = left + cellSize
                    val bottom = top + cellSize

                    when (options.dotStyle) {
                        QrDotStyle.SQUARE -> {
                            canvas.drawRect(left, top, right, bottom, fgPaint)
                        }
                        QrDotStyle.CIRCLE -> {
                            val radius = (cellSize / 2f) * 0.88f
                            canvas.drawCircle(left + cellSize / 2f, top + cellSize / 2f, radius, fgPaint)
                        }
                        QrDotStyle.ROUNDED -> {
                            val rect = RectF(left + cellSize * 0.05f, top + cellSize * 0.05f, right - cellSize * 0.05f, bottom - cellSize * 0.05f)
                            canvas.drawRoundRect(rect, cellSize * 0.35f, cellSize * 0.35f, fgPaint)
                        }
                    }
                }
            }
        }

        // 2. Draw 3 Finder Pattern Eyes with Custom Corner Styles
        fun drawFinderPatternEye(startX: Int, startY: Int) {
            val left = startX * cellSize
            val top = startY * cellSize
            val size = 7 * cellSize
            val rectOuter = RectF(left, top, left + size, top + size)
            val rectInnerBg = RectF(left + cellSize, top + cellSize, left + size - cellSize, top + size - cellSize)
            val rectCenter = RectF(left + 2 * cellSize, top + 2 * cellSize, left + size - 2 * cellSize, top + size - 2 * cellSize)

            when (options.cornerStyle) {
                QrCornerStyle.SQUARE -> {
                    canvas.drawRect(rectOuter, cornerPaint)
                    canvas.drawRect(rectInnerBg, bgPaint)
                    canvas.drawRect(rectCenter, cornerPaint)
                }
                QrCornerStyle.ROUNDED -> {
                    val radiusOuter = cellSize * 1.5f
                    val radiusInnerBg = cellSize * 1.0f
                    val radiusCenter = cellSize * 0.8f
                    canvas.drawRoundRect(rectOuter, radiusOuter, radiusOuter, cornerPaint)
                    canvas.drawRoundRect(rectInnerBg, radiusInnerBg, radiusInnerBg, bgPaint)
                    canvas.drawRoundRect(rectCenter, radiusCenter, radiusCenter, cornerPaint)
                }
                QrCornerStyle.EXTRA_ROUNDED -> {
                    val radiusOuter = cellSize * 2.8f
                    val radiusInnerBg = cellSize * 1.8f
                    val radiusCenter = cellSize * 1.2f
                    canvas.drawRoundRect(rectOuter, radiusOuter, radiusOuter, cornerPaint)
                    canvas.drawRoundRect(rectInnerBg, radiusInnerBg, radiusInnerBg, bgPaint)
                    canvas.drawRoundRect(rectCenter, radiusCenter, radiusCenter, cornerPaint)
                }
                QrCornerStyle.DOT -> {
                    // Outer ring as circle
                    val cx = left + size / 2f
                    val cy = top + size / 2f
                    canvas.drawCircle(cx, cy, size / 2f, cornerPaint)
                    canvas.drawCircle(cx, cy, (size - 2 * cellSize) / 2f, bgPaint)
                    canvas.drawCircle(cx, cy, (size - 4 * cellSize) / 2f, cornerPaint)
                }
            }
        }

        drawFinderPatternEye(0, 0)
        drawFinderPatternEye(matrixWidth - 7, 0)
        drawFinderPatternEye(0, matrixHeight - 7)

        // 3. Draw Center Logo if selected
        val centerLogoBitmap = loadLogoBitmap(options, context)
        if (centerLogoBitmap != null) {
            val logoContainerSize = (qrSize * 0.22f).toInt()
            val logoX = (qrSize - logoContainerSize) / 2f
            val logoY = (qrSize - logoContainerSize) / 2f

            // Draw clean background shield behind logo
            val shieldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = options.backgroundColor
                style = Paint.Style.FILL
            }
            val shieldBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = options.foregroundColor
                style = Paint.Style.STROKE
                strokeWidth = cellSize * 0.5f
            }

            val shieldRect = RectF(logoX, logoY, logoX + logoContainerSize, logoY + logoContainerSize)
            val cornerRadius = logoContainerSize * 0.28f
            canvas.drawRoundRect(shieldRect, cornerRadius, cornerRadius, shieldPaint)
            canvas.drawRoundRect(shieldRect, cornerRadius, cornerRadius, shieldBorderPaint)

            // Draw scaled logo inside
            val innerPadding = logoContainerSize * 0.16f
            val innerRect = RectF(
                logoX + innerPadding,
                logoY + innerPadding,
                logoX + logoContainerSize - innerPadding,
                logoY + logoContainerSize - innerPadding
            )
            canvas.drawBitmap(centerLogoBitmap, null, innerRect, Paint(Paint.FILTER_BITMAP_FLAG))
        }

        // 4. Apply Frame Style if needed
        return@withContext applyFrame(qrBitmap, options)
    }

    private fun loadLogoBitmap(options: QrDesignOptions, context: Context?): Bitmap? {
        if (context == null) return null

        // Custom logo from uri/path
        if (options.customLogoPath != null) {
            try {
                val uri = Uri.parse(options.customLogoPath)
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    return BitmapFactory.decodeStream(stream)
                }
            } catch (_: Exception) {}
        }

        // Built-in logos
        if (options.builtInLogo != BuiltInLogo.NONE) {
            return createBuiltInLogoBitmap(options.builtInLogo, options.foregroundColor)
        }

        return null
    }

    private fun createBuiltInLogoBitmap(logo: BuiltInLogo, color: Int): Bitmap {
        val size = 256
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            style = Paint.Style.FILL
        }

        when (logo) {
            BuiltInLogo.QR -> {
                // QR grid icon
                canvas.drawRoundRect(RectF(30f, 30f, 110f, 110f), 15f, 15f, paint)
                canvas.drawRoundRect(RectF(146f, 30f, 226f, 110f), 15f, 15f, paint)
                canvas.drawRoundRect(RectF(30f, 146f, 110f, 226f), 15f, 15f, paint)
                canvas.drawCircle(186f, 186f, 36f, paint)
            }
            BuiltInLogo.WEB -> {
                // Globe
                canvas.drawCircle(128f, 128f, 90f, paint.apply { style = Paint.Style.STROKE; strokeWidth = 18f })
                canvas.drawLine(38f, 128f, 218f, 128f, paint)
                canvas.drawOval(RectF(88f, 38f, 168f, 218f), paint)
            }
            BuiltInLogo.WIFI -> {
                // Wifi waves
                val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    this.color = color
                    style = Paint.Style.STROKE
                    strokeWidth = 20f
                    strokeCap = Paint.Cap.ROUND
                }
                canvas.drawArc(RectF(40f, 60f, 216f, 236f), 220f, 100f, false, wavePaint)
                canvas.drawArc(RectF(76f, 96f, 180f, 200f), 220f, 100f, false, wavePaint)
                canvas.drawCircle(128f, 195f, 16f, paint.apply { style = Paint.Style.FILL })
            }
            BuiltInLogo.CONTACT -> {
                canvas.drawCircle(128f, 85f, 40f, paint)
                canvas.drawArc(RectF(50f, 135f, 206f, 250f), 180f, 180f, true, paint)
            }
            BuiltInLogo.WHATSAPP -> {
                canvas.drawCircle(128f, 128f, 90f, paint)
                val whitePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = Color.WHITE; style = Paint.Style.FILL }
                canvas.drawCircle(128f, 128f, 60f, whitePaint)
                canvas.drawCircle(128f, 128f, 40f, paint)
            }
            BuiltInLogo.STAR -> {
                val path = android.graphics.Path()
                val cx = 128f
                val cy = 128f
                val outerRadius = 90f
                val innerRadius = 42f
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) outerRadius else innerRadius
                    val angle = Math.PI / 5 * i - Math.PI / 2
                    val x = (cx + Math.cos(angle) * r).toFloat()
                    val y = (cy + Math.sin(angle) * r).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                canvas.drawPath(path, paint)
            }
            BuiltInLogo.HEART -> {
                val path = android.graphics.Path()
                path.moveTo(128f, 190f)
                path.cubicTo(60f, 130f, 40f, 70f, 80f, 45f)
                path.cubicTo(115f, 25f, 128f, 65f, 128f, 65f)
                path.cubicTo(128f, 65f, 141f, 25f, 176f, 45f)
                path.cubicTo(216f, 70f, 196f, 130f, 128f, 190f)
                canvas.drawPath(path, paint)
            }
            BuiltInLogo.LOCK -> {
                canvas.drawRoundRect(RectF(60f, 100f, 196f, 210f), 24f, 24f, paint)
                val shacklePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    this.color = color
                    style = Paint.Style.STROKE
                    strokeWidth = 20f
                }
                canvas.drawArc(RectF(85f, 45f, 171f, 145f), 180f, 180f, false, shacklePaint)
            }
            else -> {}
        }
        return bitmap
    }

    private fun applyFrame(qrBitmap: Bitmap, options: QrDesignOptions): Bitmap {
        if (options.frameStyle == QrFrameStyle.NONE) return qrBitmap

        val qrSize = qrBitmap.width
        val margin = (qrSize * 0.08f).toInt()

        when (options.frameStyle) {
            QrFrameStyle.BORDER -> {
                val framed = Bitmap.createBitmap(qrSize + margin * 2, qrSize + margin * 2, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(framed)
                canvas.drawColor(options.backgroundColor)

                val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = options.foregroundColor
                    style = Paint.Style.STROKE
                    strokeWidth = margin * 0.25f
                }
                val borderRect = RectF(
                    margin * 0.5f,
                    margin * 0.5f,
                    framed.width - margin * 0.5f,
                    framed.height - margin * 0.5f
                )
                canvas.drawRoundRect(borderRect, margin * 0.6f, margin * 0.6f, borderPaint)
                canvas.drawBitmap(qrBitmap, margin.toFloat(), margin.toFloat(), null)
                return framed
            }
            QrFrameStyle.SCAN_ME -> {
                val headerHeight = (qrSize * 0.16f).toInt()
                val totalWidth = qrSize + margin * 2
                val totalHeight = qrSize + margin * 2 + headerHeight

                val framed = Bitmap.createBitmap(totalWidth, totalHeight, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(framed)
                canvas.drawColor(options.backgroundColor)

                // Draw outer card
                val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = options.foregroundColor
                    style = Paint.Style.STROKE
                    strokeWidth = margin * 0.2f
                }
                val cardRect = RectF(
                    margin * 0.4f,
                    margin * 0.4f,
                    totalWidth - margin * 0.4f,
                    totalHeight - margin * 0.4f
                )
                canvas.drawRoundRect(cardRect, margin * 0.8f, margin * 0.8f, cardPaint)

                // Draw QR Code
                canvas.drawBitmap(qrBitmap, margin.toFloat(), margin.toFloat(), null)

                // Draw "SCAN ME" pill at bottom
                val pillWidth = totalWidth * 0.6f
                val pillHeight = headerHeight * 0.7f
                val pillLeft = (totalWidth - pillWidth) / 2f
                val pillTop = qrSize + margin * 1.3f
                val pillRect = RectF(pillLeft, pillTop, pillLeft + pillWidth, pillTop + pillHeight)

                val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = options.foregroundColor
                    style = Paint.Style.FILL
                }
                canvas.drawRoundRect(pillRect, pillHeight / 2f, pillHeight / 2f, pillPaint)

                val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = options.backgroundColor
                    textSize = pillHeight * 0.55f
                    textAlign = Paint.Align.CENTER
                    isFakeBoldText = true
                }
                val textY = pillTop + (pillHeight / 2f) - ((textPaint.descent() + textPaint.ascent()) / 2f)
                canvas.drawText("SCAN ME", totalWidth / 2f, textY, textPaint)

                return framed
            }
            QrFrameStyle.BADGE -> {
                val totalWidth = qrSize + margin * 2
                val totalHeight = qrSize + margin * 2
                val framed = Bitmap.createBitmap(totalWidth, totalHeight, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(framed)
                canvas.drawColor(options.backgroundColor)

                val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = options.foregroundColor
                    style = Paint.Style.FILL
                }
                // Decorative top bar
                canvas.drawRoundRect(RectF(margin.toFloat(), margin * 0.3f, totalWidth - margin.toFloat(), margin * 0.65f), 10f, 10f, badgePaint)
                canvas.drawBitmap(qrBitmap, margin.toFloat(), margin.toFloat(), null)
                return framed
            }
            else -> return qrBitmap
        }
    }

    /**
     * Saves bitmap to device MediaStore / Pictures with naming format:
     * QRMaster_<Type>_<Date>.png or .jpg
     */
    suspend fun saveBitmapToGallery(
        context: Context,
        bitmap: Bitmap,
        qrType: String,
        isPng: Boolean
    ): Result<Uri> = withContext(Dispatchers.IO) {
        try {
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val cleanType = qrType.replace(" ", "").replace("/", "_")
            val extension = if (isPng) "png" else "jpg"
            val mimeType = if (isPng) "image/png" else "image/jpeg"
            val compressFormat = if (isPng) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
            val filename = "QRMaster_${cleanType}_$dateStr.$extension"

            val contentValues = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/QRMaster")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }

            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                ?: return@withContext Result.failure(Exception("Failed to create MediaStore entry"))

            resolver.openOutputStream(uri)?.use { stream ->
                if (!bitmap.compress(compressFormat, 100, stream)) {
                    return@withContext Result.failure(Exception("Failed to compress image"))
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, contentValues, null, null)
            }

            Result.success(uri)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Saves bitmap to app cache for sharing via FileProvider
     */
    suspend fun getShareableUri(
        context: Context,
        bitmap: Bitmap,
        qrType: String
    ): Result<Uri> = withContext(Dispatchers.IO) {
        try {
            val cacheDir = File(context.cacheDir, "shared_qr")
            if (!cacheDir.exists()) cacheDir.mkdirs()

            val cleanType = qrType.replace(" ", "").replace("/", "_")
            val file = File(cacheDir, "QRMaster_${cleanType}_${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }

            val authority = "${context.packageName}.fileprovider"
            val uri = FileProvider.getUriForFile(context, authority, file)
            Result.success(uri)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
