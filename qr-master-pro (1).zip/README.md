# QR Master Pro

An advanced, modern, fast, and feature-packed QR Code Scanner, Generator, and Custom Designer Android application built with **Jetpack Compose**, **Kotlin**, **CameraX**, **ZXing**, and **Material Design 3**.

---

## Features

- **High-Speed Scanner**: Real-time camera QR and barcode scanning with CameraX and ZXing.
- **Custom QR Generator**: Create QR codes for URLs, Plain Text, Wi-Fi networks, Contact Cards (vCard), Phone Numbers, SMS, and Email.
- **Custom QR Styling**: Personalize QR foreground and background colors, dot shapes, and embed custom logos.
- **Scan & Creation History**: Local persistence with search, filtering, favorite marking, and export.
- **Direct Link & Monetization**: Built-in Adsterra partner offer system and Direct Link integrations.
- **Dark & Light Mode**: Native Material 3 theming with dynamic colors and smooth transitions.
- **Cloud & Mobile Ready**: Pre-configured CI/CD workflow for automated APK building via GitHub Actions.

---

## Tech Stack & Architecture

- **Language**: Kotlin 2.2.x
- **UI Framework**: Jetpack Compose (Material 3)
- **Architecture**: MVVM (Model-View-ViewModel) + Clean Architecture
- **Scanning Engine**: Android CameraX (`androidx.camera:camera-camera2:1.5.0`) & ZXing Core (`3.5.3`)
- **Local Persistence**: Jetpack Room & DataStore Preferences
- **Build System**: Gradle 9.3+ with Kotlin DSL (`build.gradle.kts`) and Version Catalog (`libs.versions.toml`)

---

## Project Structure

```
├── .github/
│   └── workflows/
│       └── build-apk.yml       # GitHub Actions automated APK build & artifact upload
├── app/
│   ├── build.gradle.kts        # App-level build configuration & dependencies
│   ├── proguard-rules.pro      # ProGuard & R8 optimization rules
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml
│           ├── java/com/example/
│           │   ├── MainActivity.kt
│           │   ├── data/       # Room database, DAOs, models, repository
│           │   ├── service/    # AdsterraConfig, AdsterraService, QR generation utilities
│           │   └── ui/         # Screens, ViewModels, and Composables
│           │       ├── components/
│           │       ├── screens/
│           │       └── theme/
│           └── res/            # Drawables, launcher icons, strings, themes
├── gradle/
│   └── libs.versions.toml      # Gradle Version Catalog with all dependencies
├── .env.example                # Template for environment variables and secrets
├── .gitignore                  # Git ignore rules for clean repository state
├── build.gradle.kts            # Root project build configuration
├── gradle.properties           # JVM and Gradle build flags
├── metadata.json               # Google AI Studio application platform metadata
├── settings.gradle.kts         # Module includes and repository configurations
└── README.md                   # Complete documentation and setup guide
```

---

## How to Build the App

### Option A: Using Google AI Studio (Easiest - Mobile or Web)
1. Open [Google AI Studio](https://ai.studio/build).
2. Create or import your project, or upload the project ZIP.
3. The project compiles automatically in the cloud environment with streaming emulator preview.

### Option B: Automatic APK via GitHub Actions (Zero PC required)
1. Push this repository to GitHub.
2. Go to the **Actions** tab on your GitHub repository.
3. Select **Build Debug APK** and click **Run workflow**.
4. Once completed, download the generated `app-debug.apk` directly to your phone from the workflow run artifacts.

### Option C: Using Android Studio (PC / Mac / Linux)
1. Clone or download this repository.
2. Open Android Studio and select **Open** -> Choose the project root directory.
3. Allow Gradle to sync dependencies.
4. Click **Run** (`Shift + F10`) or select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

---

## License & Branding

QR Master Pro - All rights reserved. Built with modern Android best practices.
